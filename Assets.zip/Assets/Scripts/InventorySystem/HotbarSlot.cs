public class HotbarSlot : Slot
{

}
